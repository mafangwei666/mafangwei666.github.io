<?php
// on 为开启
// off&其他 为关闭

// 导航树
$GLOBALS['isTorTree'] = 'off'; // 默认显示文章导航树

// 样式
$GLOBALS['isAutoNav'] = 'off'; // 自动设置导航栏中 margin 及 width 值（推荐开启）
$GLOBALS['isIconNav'] = 'off'; // 将导航栏中的 1,2,3 替换成 Emoji 图标
$GLOBALS['isRSS'] = 'off'; // 在菜单栏中加入 RSS 按钮

$GLOBALS['style_BG'] = ''; // 背景图设置。填入图片 URL 地址，留空为关闭
